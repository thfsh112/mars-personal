# V9 A Little Photo Journal

將 index.html、style.css、script.js、admin.html 上傳到 GitHub repository 根目錄即可部署 GitHub Pages。

照片位置預留在 images/：hero.jpg、photo1.jpg～photo6.jpg。之後可直接替換。

秘密編輯密碼：mars0507。這是前端入口隱藏，不是真正安全驗證；正式後台建議使用 Supabase Auth。
